#include "all.h"

//==================================================
// Internal Variables
//==================================================

static bool bootDone = false;

static unsigned long bootStartTime = 0;

static const unsigned long BOOT_DURATION = 3000;
bool bootBegin()
{
    bootDone = false;
    bootStartTime = millis();

    animationStart(BOOT_DURATION);

    return true;
}

bool bootFinished()
{
    return bootDone;
}
void bootUpdate()
{
    animationUpdate();

    if (millis() - bootStartTime >= BOOT_DURATION)
    {
        bootDone = true;
    }
}
void bootDraw()
{
    static bool first = true;

    if (first)
    {
        displayFillScreen(COLOR_BLACK);

        displaySetTextColor(COLOR_WHITE);
        displaySetTextSize(2);
        displayPrint(10,10,"HELLO");

        first = false;
    }
}