#ifndef PORTRAITS_H
#define PORTRAITS_H

#include "all.h"

//==================================================
// Portrait Images
//==================================================

extern const Bitmap portraitBitmap;

#endif