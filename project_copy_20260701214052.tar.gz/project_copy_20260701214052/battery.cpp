#include "all.h"

//==================================================
// Internal Variables
//==================================================

static uint8_t batteryPercent = 100;

static float batteryVoltage = 4.20f;

static bool batteryLow = false;
bool batteryBegin()
{
    batteryUpdate();
    return true;
}

uint8_t batteryGetPercent()
{
    return batteryPercent;
}

float batteryGetVoltage()
{
    return batteryVoltage;
}

bool batteryIsLow()
{
    return batteryLow;
}
void batteryUpdate()
{
    int adc = analogRead(BATTERY_PIN);

    batteryVoltage = ((float)adc / 4095.0f) * 4.2f;

    if (batteryVoltage >= 4.20f)
    {
        batteryPercent = 100;
    }
    else if (batteryVoltage <= 3.30f)
    {
        batteryPercent = 0;
    }
    else
    {
        batteryPercent =
            (uint8_t)(((batteryVoltage - 3.30f) * 100.0f) / 0.90f);
    }

    batteryLow = (batteryPercent <= 20);
}
