#include "all.h"

// Replace each array with the converted RGB565 icon.

const uint16_t batteryIcon[] PROGMEM =
{
    // Battery icon
};

const uint16_t bluetoothIcon[] PROGMEM =
{
    // Bluetooth icon
};

const uint16_t settingsIcon[] PROGMEM =
{
    // Settings icon
};

const uint16_t galleryIcon[] PROGMEM =
{
    // Gallery icon
};

const uint16_t sensorIcon[] PROGMEM =
{
    // Sensor icon
};

const uint16_t levelIcon[] PROGMEM =
{
    // Level icon
};

const uint16_t stopwatchIcon[] PROGMEM =
{
    // Stopwatch icon
};

const uint16_t aboutIcon[] PROGMEM =
{
    // About icon
};

const uint16_t backIcon[] PROGMEM =
{
    // Back icon
};