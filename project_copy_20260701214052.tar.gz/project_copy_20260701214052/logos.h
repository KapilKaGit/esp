#ifndef LOGOS_H
#define LOGOS_H

#include "all.h"

//==================================================
// Logo Images
//==================================================

extern const Bitmap bootLogoBitmap;

#endif