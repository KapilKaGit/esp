#ifndef ICONS_H
#define ICONS_H

#include "all.h"

//==================================================
// Icons
//==================================================

extern const Bitmap homeIcon;
extern const Bitmap galleryIcon;
extern const Bitmap clockIcon;
extern const Bitmap sensorIcon;
extern const Bitmap levelIcon;
extern const Bitmap stopwatchIcon;
extern const Bitmap settingsIcon;
extern const Bitmap aboutIcon;

#endif