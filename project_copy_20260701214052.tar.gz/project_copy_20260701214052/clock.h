#ifndef CLOCK_H
#define CLOCK_H

#include "all.h"

//==================================================
// Clock
//==================================================

bool clockBegin();

void clockUpdate();

const char* clockGetTimeString();

#endif