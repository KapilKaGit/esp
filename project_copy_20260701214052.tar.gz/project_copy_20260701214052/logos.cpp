#include "all.h"

// Replace this with your converted RGB565 boot logo.

const uint16_t bootLogoBitmap[] PROGMEM =
{
    // RGB565 logo data goes here.
};