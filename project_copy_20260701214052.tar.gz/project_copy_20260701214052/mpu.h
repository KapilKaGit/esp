#ifndef MPU_H
#define MPU_H

#include "all.h"

//==================================================
// MPU6500
//==================================================

bool mpuBegin();

void mpuUpdate();

float mpuGetAccelX();

float mpuGetAccelY();

float mpuGetAccelZ();

float mpuGetPitch();

float mpuGetRoll();

#endif