#ifndef ALL_H
#define ALL_H

// Arduino
#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>

// Configuration
#include "pins.h"
#include "config.h"

// Hardware
#include "display.h"
#include "button.h"
#include "mpu.h"
#include "clock.h"

// Graphics
#include "bitmap.h"
#include "icons.h"

// UI
#include "ui.h"
//#include "menu.h"
#include "animation.h"

// Screens
#include "home.h"
#include "gallery.h"
#include "settings.h"

#endif