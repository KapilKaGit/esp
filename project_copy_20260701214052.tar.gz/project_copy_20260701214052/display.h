#ifndef DISPLAY_H
#define DISPLAY_H

#include "all.h"

//==================================================
// Display
//==================================================

bool displayBegin();

void displayClear();

void displayUpdate();

//==================================================
// Text
//==================================================

void displayPrint(int16_t x,
                  int16_t y,
                  const char *text);

void displaySetTextSize(uint8_t size);

void displaySetTextColor(uint16_t color);

//==================================================
// Shapes
//==================================================

void displayDrawPixel(int16_t x,
                      int16_t y);

void displayDrawLine(int16_t x0,
                     int16_t y0,
                     int16_t x1,
                     int16_t y1);

void displayDrawRect(int16_t x,
                     int16_t y,
                     int16_t w,
                     int16_t h);

void displayFillRect(int16_t x,
                     int16_t y,
                     int16_t w,
                     int16_t h);

void displayDrawRoundRect(int16_t x,
                          int16_t y,
                          int16_t w,
                          int16_t h,
                          int16_t radius);

void displayFillRoundRect(int16_t x,
                          int16_t y,
                          int16_t w,
                          int16_t h,
                          int16_t radius);

void displayDrawCircle(int16_t x,
                       int16_t y,
                       int16_t radius);

void displayFillCircle(int16_t x,
                       int16_t y,
                       int16_t radius);

//==================================================
// Bitmap
//==================================================

void displayDrawBitmap(int16_t x,
                       int16_t y,
                       uint16_t width,
                       uint16_t height,
                       const uint16_t *bitmap);

#endif