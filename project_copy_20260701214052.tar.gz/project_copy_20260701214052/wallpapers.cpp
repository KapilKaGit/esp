#include "all.h"

// Replace this with your converted RGB565 wallpaper.

const uint16_t wallpaperBitmap[] PROGMEM =
{
    // RGB565 wallpaper data goes here.
};