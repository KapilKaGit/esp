#ifndef WALLPAPERS_H
#define WALLPAPERS_H

#include "all.h"

//==================================================
// Wallpapers
//==================================================

extern const Bitmap wallpaperBitmap;

#endif